<?php
/**
 * Social Sharing Icons \ Uninstall
 * @link		http://www.oneall.com
 * @package 	oa_social_sharing_icons
 */

// If this file is called directly, abort.
if (!defined ('WP_UNINSTALL_PLUGIN'))
{
	exit ();
}
