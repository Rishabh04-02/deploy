<?php

/**
 * Social Sharing Icons \ Deactivator
 * @link		http://www.oneall.com
 * @package 	oa_social_sharing_icons
 */

/* Social Sharing Deactivator */
class oa_social_sharing_icons_Deactivator
{
	/**
	 * Called when the plugin is deactivated.
	 */
	public static function deactivate ()
	{
	}
}
